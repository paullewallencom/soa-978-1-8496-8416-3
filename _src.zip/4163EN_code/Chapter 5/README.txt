4163_05_code_01.txt
This file contains an example of how a Web Service invocation might look for a SOAP-based Web Service that retrieves customer details.

4163_05_code_02.txt
This file contains an example of how a Web Service invocation might look for a RESTful Web Service that retrieves customer details.

4163_05_code_03.txt
This file contains an example of how an XML representation of new order event might look.